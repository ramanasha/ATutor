<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate$'; ?>

<h2>Forgot Your Password</h2>

<p>If you have forgotten your password, use the <em>Forgot your password?</em> link on the Login screen. The form will email the login name to you, along with a link you must follow to change your password.</p>

<?php require('../common/body_footer.inc.php'); ?>