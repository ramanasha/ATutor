<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate: 2006-07-01 18:04:33 -0400 (Sat, 01 Jul 2006) $'; ?>

<h2>Network Profile</h2>

<p>Your Network Profile contains information about you that others might like to know, such as your work experience, education, perhaps your personal interests, or maybe your personal Web site. Click on the edit icon (<img src="../../mods/_standard/social/images/edit_profile.gif" alt="ex">)  while viewing your <strong>Network Profile</strong> to add and make changes to your personal information. Also see <a href="my_settings.php?en"><strong>Settings</strong></a> for details about controlling what parts of your profile others can see. </p>

<p>Also view <strong>Activities</strong> for a list of things you have recently done in your social network. </p>

<p>View your <strong>Contacts'</strong> profiles while viewing your own.</p>

<?php require('../common/body_footer.inc.php'); ?>
