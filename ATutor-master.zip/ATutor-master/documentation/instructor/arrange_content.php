<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate: 2006-06-29 11:25:07 -0400 (Thu, 29 Jun 2006) $'; ?>

<h2>Arrange Content</h2>

	<p>Both folders and content pages can be arranged in any order. After selecting the Arrange Content tab, select the radio button for the content you want to move. The press a downward pointing arrow next to another page or folder to move the selected page or folder after that item. Or, use the upward pointing arrow to move it before that item. Use the plus sign (+) to make the selected folder or page a child or sub-topic of the item.</p>:

	
<?php require('../common/body_footer.inc.php'); ?>