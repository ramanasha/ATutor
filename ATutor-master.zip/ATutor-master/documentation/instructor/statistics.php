<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate$'; ?>

<h2>Statistics</h2>
	<p>The statistics page displays the number of Members (registered users) and Guests (unregistered users) who have logged into the course. Use the <a href="properties.php">Properties</a> manager to control guest access to the course.</p>

<?php require('../common/body_footer.inc.php'); ?>